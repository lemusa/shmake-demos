-- ============================================================
-- SHMAKE Admin System — Full Schema
-- Run in Supabase SQL Editor
-- ============================================================

-- ─── ENUMS ───

create type job_status as enum ('lead', 'quoting', 'approved', 'in_progress', 'review', 'completed', 'on_hold', 'cancelled');
create type quote_status as enum ('draft', 'sent', 'accepted', 'declined', 'expired', 'revised');
create type invoice_status as enum ('draft', 'sent', 'viewed', 'paid', 'overdue', 'cancelled', 'refunded');
create type expense_category as enum ('materials', 'tools', 'software', 'transport', 'subcontractor', 'office', 'marketing', 'insurance', 'professional', 'other');
create type task_status as enum ('todo', 'in_progress', 'blocked', 'done');
create type task_priority as enum ('low', 'medium', 'high', 'urgent');
create type enquiry_status as enum ('new', 'contacted', 'qualifying', 'quoted', 'won', 'lost', 'archived');
create type enquiry_source as enum ('website', 'email', 'referral', 'demo', 'other');

-- ─── SETTINGS ───

create table public.settings (
  id uuid primary key default gen_random_uuid(),
  trading_name text default 'SHMAKE',
  legal_name text,
  gst_number text,
  ird_number text,
  bank_account text,
  email text,
  phone text,
  address text,
  logo_url text,
  
  -- Invoice defaults
  invoice_prefix text default 'SHMAKE-',
  invoice_next_number integer default 1,
  invoice_default_terms integer default 14,       -- days
  invoice_default_note text default 'Thank you for your business.',
  
  -- Quote defaults
  quote_prefix text default 'Q-',
  quote_next_number integer default 1,
  quote_default_expiry integer default 30,         -- days
  
  -- Tax
  gst_rate numeric(5,4) default 0.15,
  tax_year_start_month integer default 4,          -- April (NZ)
  
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Insert default row
insert into public.settings (trading_name) values ('SHMAKE');

-- ─── CLIENTS ───

create table public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  company text,
  email text,
  phone text,
  address text,
  notes text,
  is_active boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_clients_name on public.clients(name);

-- ─── CONTACTS ───

create table public.contacts (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.clients(id) on delete cascade not null,
  name text not null,
  role text,
  email text,
  phone text,
  is_primary boolean default false,
  notes text,
  created_at timestamptz default now()
);

create index idx_contacts_client on public.contacts(client_id);

-- ─── JOBS ───

create table public.jobs (
  id uuid primary key default gen_random_uuid(),
  job_number text not null unique,
  client_id uuid references public.clients(id),
  title text not null,
  description text,
  status job_status default 'lead',
  
  -- Financials
  estimated_value numeric(12,2),
  actual_value numeric(12,2),
  
  -- Dates
  start_date date,
  due_date date,
  completed_date date,
  
  notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_jobs_status on public.jobs(status);
create index idx_jobs_client on public.jobs(client_id);

-- ─── TASKS ───

create table public.tasks (
  id uuid primary key default gen_random_uuid(),
  job_id uuid references public.jobs(id) on delete cascade,
  title text not null,
  description text,
  status task_status default 'todo',
  priority task_priority default 'medium',
  due_date date,
  completed_at timestamptz,
  sort_order integer default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_tasks_job on public.tasks(job_id);
create index idx_tasks_status on public.tasks(status);

-- ─── QUOTES ───

create table public.quotes (
  id uuid primary key default gen_random_uuid(),
  quote_number text not null unique,
  job_id uuid references public.jobs(id),
  client_id uuid references public.clients(id),
  
  status quote_status default 'draft',
  version integer default 1,
  
  -- Dates
  issue_date date default current_date,
  expiry_date date,
  accepted_date date,
  
  -- Totals (calculated from line items)
  subtotal numeric(12,2) default 0,
  gst numeric(12,2) default 0,
  total numeric(12,2) default 0,
  
  notes text,                  -- Shown on PDF
  internal_notes text,         -- Admin only
  
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_quotes_job on public.quotes(job_id);
create index idx_quotes_status on public.quotes(status);

-- ─── QUOTE LINE ITEMS ───

create table public.quote_items (
  id uuid primary key default gen_random_uuid(),
  quote_id uuid references public.quotes(id) on delete cascade not null,
  description text not null,
  quantity numeric(10,2) default 1,
  unit_price numeric(12,2) not null,
  amount numeric(12,2) generated always as (quantity * unit_price) stored,
  sort_order integer default 0,
  created_at timestamptz default now()
);

create index idx_quote_items_quote on public.quote_items(quote_id);

-- ─── INVOICES ───

create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  invoice_number text not null unique,
  job_id uuid references public.jobs(id),
  client_id uuid references public.clients(id),
  quote_id uuid references public.quotes(id),     -- If created from a quote
  
  status invoice_status default 'draft',
  
  -- Dates
  issue_date date default current_date,
  due_date date,
  paid_date date,
  
  -- Totals
  subtotal numeric(12,2) default 0,
  gst numeric(12,2) default 0,
  total numeric(12,2) default 0,
  
  -- Payment
  payment_method text,
  payment_reference text,
  
  notes text,                  -- Shown on PDF
  internal_notes text,         -- Admin only
  
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_invoices_job on public.invoices(job_id);
create index idx_invoices_status on public.invoices(status);

-- ─── INVOICE LINE ITEMS ───

create table public.invoice_items (
  id uuid primary key default gen_random_uuid(),
  invoice_id uuid references public.invoices(id) on delete cascade not null,
  description text not null,
  quantity numeric(10,2) default 1,
  unit_price numeric(12,2) not null,
  amount numeric(12,2) generated always as (quantity * unit_price) stored,
  sort_order integer default 0,
  created_at timestamptz default now()
);

create index idx_invoice_items_invoice on public.invoice_items(invoice_id);

-- ─── EXPENSES ───

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  job_id uuid references public.jobs(id),          -- Null = general overhead
  date date not null default current_date,
  description text not null,
  category expense_category default 'other',
  amount numeric(12,2) not null,
  gst_amount numeric(12,2) default 0,
  is_gst_inclusive boolean default true,
  receipt_url text,
  supplier text,
  notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_expenses_job on public.expenses(job_id);
create index idx_expenses_date on public.expenses(date);
create index idx_expenses_category on public.expenses(category);

-- ─── NOTES (generic, attachable to any entity) ───

create table public.notes (
  id uuid primary key default gen_random_uuid(),
  -- Polymorphic: only one of these will be set
  job_id uuid references public.jobs(id) on delete cascade,
  client_id uuid references public.clients(id) on delete cascade,
  quote_id uuid references public.quotes(id) on delete cascade,
  invoice_id uuid references public.invoices(id) on delete cascade,
  
  content text not null,
  created_at timestamptz default now()
);

create index idx_notes_job on public.notes(job_id);
create index idx_notes_client on public.notes(client_id);

-- ============================================================
-- DEMOS MODULE
-- ============================================================

create table public.demos (
  id uuid primary key default gen_random_uuid(),
  
  slug text not null unique,
  pin char(4) not null unique,
  
  title text not null,
  description text,
  
  client_id uuid references public.clients(id),
  client_name text,                                -- For pre-client demos
  
  is_active boolean default true,
  expires_at timestamptz,
  
  view_count integer default 0,
  last_viewed_at timestamptz,
  
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_demos_pin on public.demos(pin) where is_active = true;
create index idx_demos_slug on public.demos(slug);

create table public.demo_views (
  id uuid primary key default gen_random_uuid(),
  demo_id uuid references public.demos(id) on delete cascade not null,
  viewed_at timestamptz default now(),
  ip_hint text,
  user_agent text
);

create index idx_demo_views_demo on public.demo_views(demo_id);

-- ============================================================
-- ENQUIRIES MODULE
-- ============================================================

create table public.enquiries (
  id uuid primary key default gen_random_uuid(),
  
  name text not null,
  email text not null,
  phone text,
  company text,
  message text,
  
  status enquiry_status default 'new',
  source enquiry_source default 'website',
  
  client_id uuid references public.clients(id),
  job_id uuid references public.jobs(id),
  demo_id uuid references public.demos(id),
  
  notes text,
  
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index idx_enquiries_status on public.enquiries(status);
create index idx_enquiries_created on public.enquiries(created_at desc);

-- ============================================================
-- RLS POLICIES
-- ============================================================
-- Single-user system: admin auth required for everything.
-- Public access is handled via edge functions with service role key.

alter table public.settings enable row level security;
alter table public.clients enable row level security;
alter table public.contacts enable row level security;
alter table public.jobs enable row level security;
alter table public.tasks enable row level security;
alter table public.quotes enable row level security;
alter table public.quote_items enable row level security;
alter table public.invoices enable row level security;
alter table public.invoice_items enable row level security;
alter table public.expenses enable row level security;
alter table public.notes enable row level security;
alter table public.demos enable row level security;
alter table public.demo_views enable row level security;
alter table public.enquiries enable row level security;

-- Admin has full access to everything (authenticated user = you)
do $$
declare
  t text;
begin
  for t in select unnest(array[
    'settings','clients','contacts','jobs','tasks',
    'quotes','quote_items','invoices','invoice_items',
    'expenses','notes','demos','demo_views','enquiries'
  ]) loop
    execute format(
      'create policy "Admin full access" on public.%I for all to authenticated using (true) with check (true)',
      t
    );
  end loop;
end $$;

-- ============================================================
-- HELPER FUNCTIONS
-- ============================================================

-- Auto-generate next job number
create or replace function public.next_job_number()
returns text language sql as $$
  select 'J-' || lpad((coalesce(max(substring(job_number from 3)::integer), 0) + 1)::text, 4, '0')
  from public.jobs;
$$;

-- Auto-generate next invoice number (uses settings prefix)
create or replace function public.next_invoice_number()
returns text language sql as $$
  select s.invoice_prefix || lpad(s.invoice_next_number::text, 4, '0')
  from public.settings s limit 1;
$$;

-- Auto-generate next quote number
create or replace function public.next_quote_number()
returns text language sql as $$
  select s.quote_prefix || lpad(s.quote_next_number::text, 4, '0')
  from public.settings s limit 1;
$$;

-- Increment invoice/quote counter after use
create or replace function public.increment_invoice_counter()
returns trigger language plpgsql as $$
begin
  update public.settings set invoice_next_number = invoice_next_number + 1;
  return new;
end;
$$;

create trigger trg_increment_invoice
  after insert on public.invoices
  for each row execute function public.increment_invoice_counter();

create or replace function public.increment_quote_counter()
returns trigger language plpgsql as $$
begin
  update public.settings set quote_next_number = quote_next_number + 1;
  return new;
end;
$$;

create trigger trg_increment_quote
  after insert on public.quotes
  for each row execute function public.increment_quote_counter();

-- Recalculate quote totals when items change
create or replace function public.recalc_quote_totals()
returns trigger language plpgsql as $$
declare
  q_id uuid;
  sub numeric;
  rate numeric;
begin
  q_id := coalesce(new.quote_id, old.quote_id);
  select coalesce(sum(quantity * unit_price), 0) into sub from public.quote_items where quote_id = q_id;
  select gst_rate into rate from public.settings limit 1;
  update public.quotes set subtotal = sub, gst = round(sub * rate, 2), total = round(sub * (1 + rate), 2), updated_at = now() where id = q_id;
  return new;
end;
$$;

create trigger trg_recalc_quote
  after insert or update or delete on public.quote_items
  for each row execute function public.recalc_quote_totals();

-- Same for invoices
create or replace function public.recalc_invoice_totals()
returns trigger language plpgsql as $$
declare
  i_id uuid;
  sub numeric;
  rate numeric;
begin
  i_id := coalesce(new.invoice_id, old.invoice_id);
  select coalesce(sum(quantity * unit_price), 0) into sub from public.invoice_items where invoice_id = i_id;
  select gst_rate into rate from public.settings limit 1;
  update public.invoices set subtotal = sub, gst = round(sub * rate, 2), total = round(sub * (1 + rate), 2), updated_at = now() where id = i_id;
  return new;
end;
$$;

create trigger trg_recalc_invoice
  after insert or update or delete on public.invoice_items
  for each row execute function public.recalc_invoice_totals();

-- Generate unique 4-digit demo pin
create or replace function public.generate_demo_pin()
returns char(4) language plpgsql as $$
declare
  new_pin char(4);
begin
  loop
    new_pin := lpad(floor(random() * 10000)::text, 4, '0');
    exit when not exists (select 1 from public.demos where pin = new_pin);
  end loop;
  return new_pin;
end;
$$;

-- Updated_at trigger
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- Apply updated_at trigger to all relevant tables
do $$
declare
  t text;
begin
  for t in select unnest(array[
    'settings','clients','jobs','tasks','quotes','invoices','expenses','demos','enquiries'
  ]) loop
    execute format(
      'create trigger trg_updated_at before update on public.%I for each row execute function public.set_updated_at()',
      t
    );
  end loop;
end $$;

-- Increment demo view count (called by edge function)
create or replace function public.increment_demo_views(demo_id uuid)
returns void language plpgsql security definer as $$
begin
  update public.demos
  set view_count = view_count + 1, last_viewed_at = now()
  where id = demo_id;
end;
$$;

-- ============================================================
-- SEED DATA — your first demo
-- ============================================================

insert into public.demos (slug, pin, title, client_name, is_active)
values ('ecoglo-luminance', '8472', 'Luminance Testing Module', 'Ecoglo', true);
