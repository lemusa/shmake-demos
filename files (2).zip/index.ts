// supabase/functions/validate-pin/index.ts
//
// Public endpoint for demo.shmake.nz pin validation
// Deploy: supabase functions deploy validate-pin --no-verify-jwt

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

Deno.serve(async (req) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ valid: false }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  try {
    const { pin } = await req.json()

    if (!pin || typeof pin !== 'string' || pin.length < 4 || pin.length > 6) {
      return new Response(JSON.stringify({ valid: false }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Look up active demo by pin
    const { data: demo, error } = await supabase
      .from('demos')
      .select('id, slug, expires_at')
      .eq('pin', pin)
      .eq('is_active', true)
      .single()

    if (error || !demo) {
      return new Response(JSON.stringify({ valid: false }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Check expiry
    if (demo.expires_at && new Date(demo.expires_at) < new Date()) {
      return new Response(JSON.stringify({ valid: false }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Increment view count and log the view
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || ''
    const ipHint = ip.split('.').slice(0, 2).join('.') + '.*.*'

    await Promise.all([
      supabase.rpc('increment_demo_views', { demo_id: demo.id }),
      supabase.from('demo_views').insert({
        demo_id: demo.id,
        ip_hint: ipHint,
        user_agent: req.headers.get('user-agent')?.substring(0, 200) || null,
      }),
    ])

    return new Response(JSON.stringify({ valid: true, slug: demo.slug }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch {
    return new Response(JSON.stringify({ valid: false }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
